
     function onSubmit() {
          if (document.getElementById('password').value == 'user123' && document.getElementById('username').value=='user') {window.location.href = 'http://google.com'; }
          else if (document.getElementById('password').value == 'admin123' && document.getElementById('username').value=='admin') {window.location.href = 'http://google.com'; }
          else{ alert('Please try again');}
     }

